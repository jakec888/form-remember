// import {GET_STORED_INPUTS, UPDATE_VISIBLE_TEXT_INPUT, IMPORT_JSON} from '../constants/input';

// export const getStoreInputs = (data, visibleTextInputs) => ({
//   type: GET_STORED_INPUTS,
//   payload: {data, visibleTextInputs},
// });

// export const updateVisibleTextInput = visibleTextInputs => ({
//   type: UPDATE_VISIBLE_TEXT_INPUT,
//   payload: {visibleTextInputs},
// });

// export const getStoreInputs = importing => ({
//   type: IMPORT_JSON,
//   payload: {importing},
// });
